---
name: Help
about: Need help finishing the tutorial?
title: ''
labels: ''
assignees: ''

---

# Category

Which of these applies to you? _(Select all that apply)_

- [ ] I'm following the tutorial as-written from start to finish
- [ ] I'm using a custom domain (note: not covered in tutorial)
- [ ] I'm using React Router (note: not covered in tutorial)

# Step

Which step of the tutorial do you want someone to help you with? _(Select one)_

- [ ] Step number: _(put the number here)_
- [ ] Something else

# Links

Tell us where we can find your code and your GitHub Pages site:

- GitHub repository (source code): 
- GitHub Pages site (deployed app): 

# Everything else

_You can put whatever you want into this section._

...
